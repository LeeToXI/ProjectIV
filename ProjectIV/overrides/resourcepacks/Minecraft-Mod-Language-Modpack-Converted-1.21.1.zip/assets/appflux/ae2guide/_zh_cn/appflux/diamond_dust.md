---
navigation:
  parent: appflux/appflux-index.md
  title: 钻石粉
  icon: appflux:diamond_dust
categories:
- flux materials
item_ids:
- appflux:diamond_dust
---

# 钻石粉

<Row>
<ItemImage id="appflux:diamond_dust" scale="4"></ItemImage>
</Row>

磨成粉的钻石。
