---
navigation:
  parent: appflux/appflux-index.md
  title: 绝缘树脂
  icon: appflux:insulating_resin
categories:
- flux materials
item_ids:
- appflux:insulating_resin
- appflux:harden_insulating_resin
---

# 绝缘树脂

<Row>
<ItemImage id="appflux:insulating_resin" scale="4"></ItemImage>
<ItemImage id="appflux:harden_insulating_resin" scale="4"></ItemImage>
</Row>

绝缘树脂可防止存储的能量泄走。它是制作FE元件外壳的必需原材料。
