---
navigation:
  parent: appflux/appflux-index.md
  title: 终端交互
categories:
- flux tricks
---

# 终端交互

终端会将存有的能量显示为下图中的*绿色流体*。

![FE_GUI](../pic/fe_terminal.png)

它并非真实存在的流体，也无法用铁桶盛装。

不过，你可以使用电池、电动工具等能量容器向其存入/从其抽取能量。

![FE_GUI2](../pic/fe_terminal2.png)

