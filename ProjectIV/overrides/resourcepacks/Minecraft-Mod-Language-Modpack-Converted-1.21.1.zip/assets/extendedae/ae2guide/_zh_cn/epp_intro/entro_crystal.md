---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: 恩特罗水晶
    icon: extendedae:entro_crystal
categories:
- entro system
item_ids:
- extendedae:entro_crystal
---

# 恩特罗水晶

<Row>
<ItemImage id="extendedae:entro_crystal" scale="4"></ItemImage>
</Row>

*“将末影粉注入福鲁伊克斯水晶后，所得的恩特罗水晶表现出了极强的维度亲和性，还会与时空产生共振。”*

AE2扩展中大部分物品与机器的主要合成材料。需使用<ItemLink id="extendedae:entro_seed" />将<ItemLink id="ae2:fluix_block" />转变为[恩特罗化的福鲁伊克斯母岩](entro_budding.md)，再破坏恩特罗簇以获得恩特罗水晶。
