---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: 恩特罗粉
    icon: extendedae:entro_dust
categories:
- entro system
item_ids:
- extendedae:entro_dust
---

# 恩特罗粉

<Row>
<ItemImage id="extendedae:entro_dust" scale="4"></ItemImage>
</Row>

通过粉碎<ItemLink id="extendedae:entro_crystal" />或破坏[恩特罗化的福鲁伊克斯母岩](entro_budding.md)获得。

它可用于合成部分AE2扩展的机器，以及<ItemLink id="extendedae:entro_ingot" />。
