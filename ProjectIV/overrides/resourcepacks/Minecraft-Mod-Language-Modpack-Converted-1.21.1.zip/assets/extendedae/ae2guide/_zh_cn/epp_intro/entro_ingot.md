---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: 恩特罗融注锭
    icon: extendedae:entro_ingot
categories:
- entro system
item_ids:
- extendedae:entro_ingot
---

# 恩特罗融注锭

<Row>
<ItemImage id="extendedae:entro_ingot" scale="4"></ItemImage>
</Row>

*“恩特罗水晶的结构较为松散，不适合用来制造机器框架，但可将其与金锭融合以增强其延性。”*

用于合成<ItemLink id="extendedae:machine_frame" />和其他几种AE2扩展的机器。
