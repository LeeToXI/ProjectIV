---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: 恩特罗种子
    icon: extendedae:entro_seed
categories:
- entro system
item_ids:
- extendedae:entro_seed
---

# 恩特罗种子

<Row>
<ItemImage id="extendedae:entro_seed" scale="4"></ItemImage>
</Row>

这些种子带有强大的恩特罗能量。以恩特罗种子右击<ItemLink id="ae2:fluix_block" />可将其变为[恩特罗化的福鲁伊克斯母岩](entro_budding.md)；也可选择借助<ItemLink id="extendedae:crystal_assembler" />注入种子，但产出的[恩特罗化的福鲁伊克斯母岩](entro_budding.md)比手动操作得来的品级低。
