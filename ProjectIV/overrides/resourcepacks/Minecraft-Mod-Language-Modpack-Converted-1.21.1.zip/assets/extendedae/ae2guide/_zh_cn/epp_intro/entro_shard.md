---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: 恩特罗碎片
    icon: extendedae:entro_shard
categories:
- entro system
item_ids:
- extendedae:entro_shard
---

# 恩特罗碎片

<Row>
<ItemImage id="extendedae:entro_shard" scale="4"></ItemImage>
</Row>

破坏未长成的[恩特罗芽](entro_budding.md)会掉落恩特罗碎片。8个恩特罗碎片可合成回<ItemLink id="extendedae:entro_crystal" />。
